let jobs = [
    { title: 'Software Developer Intern', company: 'ABC Tech', location: 'Remote', description: 'Develop cool projects with the team.', university: 'Sharda University', department: 'Computer Science' },
    { title: 'Marketing Assistant', company: 'XYZ Corp', location: 'On-campus', description: 'Help with marketing campaigns for university.', university: 'Sharda University', department: 'Business Administration' },
    { title: 'Graphic Designer', company: 'Creative Studio', location: 'Remote', description: 'Design graphics for various projects.', university: 'Sharda University', department: 'Design' },
    { title: 'Data Analyst', company: 'Data Works', location: 'On-campus', description: 'Analyze and present data insights.', university: 'Sharda University', department: 'Mathematics' },
    { title: 'Web Developer', company: 'Tech Solutions', location: 'Hybrid', description: 'Work on web-based projects for clients.', university: 'Sharda University', department: 'Computer Science' },
    { title: 'Research Assistant', company: 'University Research Center', location: 'On-campus', description: 'Assist in academic research projects.', university: 'Sharda University', department: 'Physics' },
];

let displayedJobs = [];
let currentUser = null;

// Mock user credentials (In real-world, this would be handled with a backend)
const validEmail = "utkarsh@sharda.edu";
const validPassword = "2022001453";

// Function to simulate student login
function login() {
    const email = document.getElementById('emailInput').value;
    const password = document.getElementById('passwordInput').value;
    const errorMessage = document.getElementById('loginError');
    
    if (email === validEmail && password === validPassword) {
        currentUser = email;
        // Hide login form and show job listings page
        document.getElementById('loginForm').classList.add('hidden');
        document.getElementById('jobPage').classList.remove('hidden');
        loadMoreJobs();
    } else {
        errorMessage.textContent = "Invalid email or password.";
    }
}

// Display Jobs Function
function displayJobs(jobList) {
    const jobListContainer = document.getElementById('jobList');
    jobListContainer.innerHTML = ''; // Clear previous job listings

    jobList.forEach(job => {
        const jobItem = document.createElement('div');
        jobItem.classList.add('job-item');
        jobItem.innerHTML = `
            <h3>${job.title}</h3>
            <p><strong>${job.company}</strong> - ${job.location}</p>
            <p><strong>University:</strong> ${job.university}</p>
            <p><strong>Department:</strong> ${job.department}</p>
            <p><strong>Description:</strong> ${job.description}</p>
        `;
        jobListContainer.appendChild(jobItem);
    });
}

// Load More Jobs Function
function loadMoreJobs() {
    const remainingJobs = jobs.slice(displayedJobs.length);
    const jobsToLoad = remainingJobs.slice(0, 3); // Load 3 more jobs
    displayedJobs = displayedJobs.concat(jobsToLoad); // Add to the already displayed jobs
    displayJobs(displayedJobs);
}

// Search Jobs Function
function searchJobs() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    const filteredJobs = jobs.filter(job => 
        job.title.toLowerCase().includes(query) || 
        job.company.toLowerCase().includes(query) || 
        job.location.toLowerCase().includes(query) ||
        job.department.toLowerCase().includes(query)
    );
    displayJobs(filteredJobs);
}

// Load more jobs when the "Load More Jobs" button is clicked
document.getElementById('loadMoreBtn').addEventListener('click', loadMoreJobs);

